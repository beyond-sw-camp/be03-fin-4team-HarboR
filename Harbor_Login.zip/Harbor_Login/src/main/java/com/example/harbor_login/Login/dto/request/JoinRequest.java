package com.example.harbor_login.Login.dto.request;

import lombok.Data;

@Data
public class JoinRequest {
    private String email;
}
