package com.example.harbor_login.global.support;

public enum Role {
    USER,ADMIN;
}

